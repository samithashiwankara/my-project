<!DOCTYPE HTML>

<head>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
   <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
   <script src="js/jquery.min.js"></script>
   <script src='http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script>
   <script type='text/javascript' src='menu_jquery.js'></script>
   <link rel='stylesheet' type='text/css' href='styles.css' />
   <link rel='stylesheet' type='text/css' href='table.css' />
   <link rel='stylesheet' type='text/css' href='bootstrap.css' />
</head>

<body>
   <div class="header">
      <div class="header_top">
         <div class="wrap">
            <div class="call">
               <p><img src="images/45.png" alt="" />Call US: 111-234-56789</p>
            </div>

            <div class="clear"></div>
         </div>
      </div>
      <div class="header_bottom">
         <div class="wrap">
            <div id='cssmenu'>
               <ul>
                  <li><a href='home.php'><span>Home</span></a></li>

                  <li class='has-sub'><a href='#'><span>Treatments</span></a>
                     <ul>
                        <li><a href='Treatment_Select.php'><span>Treatments</span></a></li>

                        <li><a href='Item_master_Select.php'><span>Items</span></a></li>
                        <li><a href='Item_treatment_Select.php'><span>Treatment Items</span></a></li>


                     </ul>
                  </li>
                  <li class='has-sub'><a href='#'><span>Customers</span></a>
                     <ul>
                        <li><a href='Customer_Select.php'><span>Customer Details</span></a> </li>
                        <li><a href='Package_booking_Select.php'><span>Package Booking</span></a></li>
                        <li><a href='Treatment_booking_Select.php'><span>Treatment Bookings</span></a></li>
                        <li><a href='Schedule_Select.php'><span>Schedules</span></a></li>

                     </ul>
                  </li>
                  <li class='has-sub'><a href='#'><span>Reports</span></a>
                     <ul>
                        <li><a href='Package_report_Select.php'><span>Packages</span></a> </li>
                        <li><a href='Treatment_report_Select.php'><span>Treatments</span></a></li>
                        <li><a href='Transaction_report_Select.php'><span>Customer Transactions</span></a></li>
                        <!--<li ><a href='Billmaster_report_Select.php'><span>Item bill Report</span></a> </li>-->
                        <li><a href='Feedback_Select.php'><span>Feedback</span></a></li>


                     </ul>
                  </li>
                  <li class='has-sub'><a href='#'><span>Profile Settings</span></a>
                     <ul>
                        <li><a href='Staff_master_Edit.php'><span>Update</span></a> </li>
                        <li><a href='Changepassword.php'><span>Change Password</span></a></li>
                        <li><a href='logout.php'><span>Logout</span></a></li>


                     </ul>
                  </li>


               </ul>