<?php
    $con=mysqli_connect('localhost','root','','salon_management');
