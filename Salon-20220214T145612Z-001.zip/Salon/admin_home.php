<?php
include 'admin_header.php';
	echo "<center><h1>Welcome Admin..!!!</h1>";
?>
	     	<div class="clear"></div>
	      </div>	     
	  </div>	
	  </div>
	   
       <div class="slider">
       	 <div class="wrap">
       	   <div class="slider_top">         
         		<div class="slider_left">
				  <div class="wmuSlider example2">
					<div class="wmuSliderWrapper">
					<article> <img src="images/17.jpg" alt="" /> </article>
					</div>	
					<script src="js/jquery.wmuSlider.js"></script> 
								
				 </div>
				</div>				
				   <div class="slider_right">
				      <img src="images/bopal.jpg" alt="" style="    height: 420px; width: 500px;"/>
				         <div class="sliderright-text">
				  
				       </div>
				   </div>
				<?php
include 'footer.php';
				?>
				