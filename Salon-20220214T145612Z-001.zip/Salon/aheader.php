<!DOCTYPE HTML>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<script src="js/jquery.min.js"></script> 
<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script>
	<script type='text/javascript' src='menu_jquery.js'></script>
    <link rel='stylesheet' type='text/css' href='styles.css' />
    <link rel='stylesheet' type='text/css' href='table.css' />
	<link rel='stylesheet' type='text/css' href='bootstrap.css' />
</head>
<body>
	<div class="header">
		<div class="header_top">
			<div class="wrap">
			 <div class="logo">
						<a href="index.html"><img src="images/47.png" alt="" /></a>
					</div>
			    <div class="call">
			    	<p><img src="images/45.png" alt="" />Call US: 111-234-56789</p>
			    </div>
			  			 
			<div class="clear"></div>
	      </div>	     
	   
  	
	<div class="header_bottom">
		<div class="wrap">
	     	<div id='cssmenu'>
<ul>
			    	<li class="active"><a href="index.php">Home</a></li>
			    	<li><a href="login.php">Login</a></li>
			    	<li><a href="Customer_Add.php">Register</a></li>	
					<li><a href="services.php">Services</a></li>					
			    	<li><a href="about.php">About Us</a></li>
			    	
			    	<div class="clear"></div>
     			</ul>
</div>
	  </div>
    </div> 
		
		    </div>
		  </div>
		</div> 
		<div class="clear"></div>
	      </div>	     
	  </div>	
	   <div class="strip"> </div>
    </div>
	 </div>
 <div class="main">
    <div class="content">
    	 <div class="wrap">
    	 	<div class="image group">
				<div class="grid span_2_of_3">	
