<?php
include 'admin_header.php';
?>
				
				
 
    <ul id="contentUl">
    <div id="rightDiv">
        	<form action="brand_validation.php" method="post">
			<h1><font color="green">ADD BRAND</h1></font>
            	<li><label>Brand Name:</label><input type="text" name="txtBrandName" placeholder="Enter the Brand name..." required/></li>
                <li><input  type="submit" name="Save" value="Save"/></li>
    		</form>
   
    </ul>
    </div>
    </div>
	<a href="view_brand.php">View Brands</a>
</body>
</html>
